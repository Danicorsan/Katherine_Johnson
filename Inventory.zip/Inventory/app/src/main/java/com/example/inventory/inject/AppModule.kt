package com.example.inventory.inject
