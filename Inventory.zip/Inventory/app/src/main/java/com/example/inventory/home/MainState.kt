package com.example.inventory.home

data class MainState(val activeAccount: Boolean) {

}
