plugins {
    alias(libs.plugins.app.jvm.library)
}