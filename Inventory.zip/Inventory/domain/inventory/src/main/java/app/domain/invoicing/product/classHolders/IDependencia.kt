package app.domain.invoicing.product.classHolders

interface IDependencia {
    val nombreCorto : String
}