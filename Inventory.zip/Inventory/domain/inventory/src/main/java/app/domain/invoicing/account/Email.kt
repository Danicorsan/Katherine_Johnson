package app.domain.invoicing.account

data class Email(val value:String) {
}
