package app.domain.invoicing.product.complements.notes

data class Nota (
    var titulo: String,
    var cuerpo : String
)