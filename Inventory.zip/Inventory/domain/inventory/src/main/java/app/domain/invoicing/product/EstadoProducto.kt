package app.domain.invoicing.product

enum class EstadoProducto {
    new,
    modified,
    verified;
}