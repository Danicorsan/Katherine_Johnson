package app.domain.invoicing.util


fun Double.isNegativeOrZero() = this <= 0

