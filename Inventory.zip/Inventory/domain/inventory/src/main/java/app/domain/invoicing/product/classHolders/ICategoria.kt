package app.domain.invoicing.product.classHolders

interface ICategoria {
    val nombre : String
}