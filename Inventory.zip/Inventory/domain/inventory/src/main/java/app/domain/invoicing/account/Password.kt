package app.domain.invoicing.account

data class Password(val value: String) {

}
