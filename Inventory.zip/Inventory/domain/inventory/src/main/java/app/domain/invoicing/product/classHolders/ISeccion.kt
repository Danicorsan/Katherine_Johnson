package app.domain.invoicing.product.classHolders

interface ISeccion {
    val nombreSeccion : String
}