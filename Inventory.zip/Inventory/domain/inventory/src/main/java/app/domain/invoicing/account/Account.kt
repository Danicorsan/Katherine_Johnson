package app.domain.invoicing.account

data class Account(val name: String, val email: String, val password: String){

}
