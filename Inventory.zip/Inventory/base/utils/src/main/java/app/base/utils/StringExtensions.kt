package app.base.utils

val String.Companion.Empty: String
    get() = ""