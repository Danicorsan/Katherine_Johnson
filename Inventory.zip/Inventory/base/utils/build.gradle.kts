plugins {
    alias(libs.plugins.app.jvm.library)
}

dependencies{
    implementation(libs.kotlinx.datetime)
}