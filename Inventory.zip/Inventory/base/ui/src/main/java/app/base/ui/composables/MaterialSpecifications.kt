package app.base.ui.composables

import androidx.compose.ui.unit.dp

object Separations {
    val Small = 8.dp
    val Medium = 16.dp
}