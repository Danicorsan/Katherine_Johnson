package app.builddomain.plugins

object PlatformVersions {
    const val Min = 24
    const val Compile = 34
    const val Target = 34
}